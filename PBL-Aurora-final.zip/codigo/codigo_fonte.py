# ==============================================================================
# NÚCLEO COGNITIVO DA AURORA SIGER (NCAS) — FASE 5
# Arquivo principal do sistema
#
# Integrante 1 — Desenvolvimento Core e Estrutura de Dados
#   - Esqueleto do menu de navegação no terminal
#   - Funções de leitura/gravação em registros_colonia.txt (open, read, write, append)
#   - Funções de carregar/salvar dados_colonia.json
#
# Integrante 2 — Regra Lógica e Engenharia de Prompts
#   - validar_alerta_critico()      -> regra booleana simplificada (De Morgan/Simplificação)
#   - montar_prompt_*()             -> prompts zero-shot / few-shot / saída estruturada
#   - simular_resposta_assistente() -> resposta real (Gemini, se disponível) ou mock local
#
# A integração com IA é OPCIONAL (item 2.3 do enunciado): se a biblioteca
# google-genai/dotenv não estiver instalada, ou a GEMINI_API_KEY não existir,
# o sistema cai automaticamente para uma resposta simulada localmente —
# o programa nunca quebra por causa disso.
# ==============================================================================

import json
import os
from datetime import datetime

# ------------------------------------------------------------------------
# CAMINHOS DE ARQUIVO — resolvidos a partir da localização deste script
# (e não do diretório de onde o programa é executado), para que
# "python codigo/codigo_fonte.py" e "python main.py" encontrem os mesmos
# arquivos em ../dados/, independentemente da pasta atual do terminal.
# ------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DADOS_DIR = os.path.normpath(os.path.join(BASE_DIR, "..", "dados"))
ARQUIVO_REGISTROS = os.path.join(DADOS_DIR, "registros_colonia.txt")
ARQUIVO_DADOS = os.path.join(DADOS_DIR, "dados_colonia.json")

os.makedirs(DADOS_DIR, exist_ok=True)  # garante que a pasta dados/ exista

# ------------------------------------------------------------------------
# INTEGRAÇÃO OPCIONAL COM IA (mesmo padrão usado em main.py)
# ------------------------------------------------------------------------
try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass

_API_KEY = os.getenv("GEMINI_API_KEY")

try:
    from google import genai

    _client = genai.Client(api_key=_API_KEY) if _API_KEY else None
except ImportError:
    _client = None


# ------------------------------------------------------------------------
# FUNÇÕES AUXILIARES DE VALIDAÇÃO E ERRO
# ------------------------------------------------------------------------
def validar_nome_modulo(nome: str) -> bool:
    """Valida se o nome do módulo é válido (não vazio e tamanho razoável)."""
    return bool(nome and len(nome.strip()) >= 2 and len(nome) <= 50)


def validar_tipo_modulo(tipo: str) -> bool:
    """Valida se o tipo do módulo é válido."""
    tipos_validos = {"habitacao", "energia", "laboratorio", "comunicacao",
                     "controle", "logistica", "medico", "agricultura", "infraestrutura"}
    return bool(tipo and tipo.lower() in tipos_validos)


def validar_status_modulo(status: str) -> bool:
    """Valida se o status do módulo é válido."""
    status_validos = {"operacional", "inativo", "manutencao"}
    return bool(status and status.lower() in status_validos)


def validar_consumo_kw(consumo: float) -> bool:
    """Valida se o consumo em kW está dentro de limites razoáveis."""
    return isinstance(consumo, (int, float)) and 0 <= consumo <= 10000  # 0 a 10MW


def validar_dados_modulo(nome: str, tipo: str, status: str, consumo: float) -> tuple[bool, str]:
    """
    Valida todos os dados de um módulo.
    Retorna (é_válido, mensagem_de_erro).
    """
    if not validar_nome_modulo(nome):
        return False, "Nome do módulo inválido (deve ter entre 2 e 50 caracteres)"

    if not validar_tipo_modulo(tipo):
        return False, "Tipo de módulo inválido"

    if not validar_status_modulo(status):
        return False, "Status inválido (use: operacional, inativo ou manutencao)"

    if not validar_consumo_kw(consumo):
        return False, "Consumo deve ser um número entre 0 e 10000 kW"

    return True, ""


def carregar_dados_com_seguranca() -> dict:
    """
    Carrega os dados JSON com tratamento de erros.
    Retorna os dados ou uma estrutura vazia em caso de erro.
    """
    try:
        if not os.path.exists(ARQUIVO_DADOS):
            return {"modulos": [], "alertas": []}

        with open(ARQUIVO_DADOS, "r", encoding="utf-8") as arquivo:
            dados = json.load(arquivo)

        # Garante que a estrutura esperada existe
        if not isinstance(dados, dict):
            return {"modulos": [], "alertas": []}

        dados.setdefault("modulos", [])
        dados.setdefault("alertas", [])

        return dados
    except (json.JSONDecodeError, IOError, OSError) as e:
        gravar_registro(f"Erro ao carregar dados JSON: {str(e)}", tipo="ERRO")
        return {"modulos": [], "alertas": []}


def salvar_dados_com_seguranca(dados: dict) -> bool:
    """
    Salva os dados JSON com tratamento de erros.
    Retorna True se salvou com sucesso, False caso contrário.
    """
    try:
        with open(ARQUIVO_DADOS, "w", encoding="utf-8") as arquivo:
            json.dump(dados, arquivo, indent=2, ensure_ascii=False)
        return True
    except (IOError, OSError) as e:
        gravar_registro(f"Erro ao salvar dados JSON: {str(e)}", tipo="ERRO")
        return False


def imprimir_quadro(titulo: str, linhas: list) -> None:
    """Exibe um bloco de texto formatado no terminal (padrão usado nas outras fases)."""
    largura = 70
    print("-" * largura)
    print(f"| {titulo.center(largura - 4)} |")
    print("|" + " " * (largura - 2) + "|")
    for linha in linhas:
        print(f"| {linha.ljust(largura - 4)} |")
    print("-" * largura)


# ==============================================================================
# BLOCO 1 — MANIPULAÇÃO DE ARQUIVO TEXTO (registros_colonia.txt)
#
# Por que TXT? Registros de log, acessos e ocorrências são eventos sequenciais,
# de formato livre, gerados continuamente durante a execução. Não precisam ser
# consultados por campo específico — apenas lidos em ordem ou anexados um a um.
# O modo "append" (a) é ideal para isso: cada evento novo é gravado ao final do
# arquivo sem necessidade de reescrever o conteúdo já existente.
# ==============================================================================


def gravar_registro(mensagem: str, tipo: str = "LOG") -> None:
    """Adiciona uma nova linha ao arquivo de registros (modo append)."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    linha = f"[{timestamp}] [{tipo}] {mensagem}\n"
    with open(ARQUIVO_REGISTROS, "a", encoding="utf-8") as arquivo:
        arquivo.write(linha)
    print("\n >> Registro salvo com sucesso.")


def ler_registros() -> None:
    """Lê e exibe todo o conteúdo do arquivo de registros (modo read)."""
    if not os.path.exists(ARQUIVO_REGISTROS):
        print(f"\n >> Nenhum registro encontrado ainda em: {ARQUIVO_REGISTROS}")
        return

    with open(ARQUIVO_REGISTROS, "r", encoding="utf-8") as arquivo:
        linhas = [linha.strip() for linha in arquivo.readlines() if linha.strip()]

    if not linhas:
        print("\n >> O arquivo de registros existe, mas está vazio.")
        return

    print(f"\n--- REGISTROS DA COLÔNIA ({len(linhas)} entradas) ---")
    for i, linha in enumerate(linhas, start=1):
        print(f"  {i:>3}. {linha}")
    print("-" * 60)


# ==============================================================================
# BLOCO 2 — MANIPULAÇÃO DE ARQUIVO JSON (dados_colonia.json)
#
# Por que JSON? Módulos e alertas possuem uma estrutura fixa de campos
# (nome, status, consumo, prioridade...) que precisa ser consultada,
# validada e atualizada de forma organizada — inclusive pelas regras lógicas
# do Integrante 2. Um dicionário/lista de dicionários representa isso melhor
# do que texto livre, e o módulo json permite carregar e salvar essa estrutura
# de forma direta.
# ==============================================================================


def carregar_dados_json() -> dict:
    """Carrega os dados estruturados (módulos e alertas) do arquivo JSON."""
    if not os.path.exists(ARQUIVO_DADOS):
        print(f"\n >> Arquivo de dados JSON não encontrado em: {ARQUIVO_DADOS}")
        print("\n >> Iniciando estrutura vazia.")
        return {"modulos": [], "alertas": []}

    with open(ARQUIVO_DADOS, "r", encoding="utf-8") as arquivo:
        return json.load(arquivo)


def salvar_dados_json(dados: dict) -> None:
    """Salva a estrutura completa de dados (módulos e alertas) no arquivo JSON."""
    with open(ARQUIVO_DADOS, "w", encoding="utf-8") as arquivo:
        json.dump(dados, arquivo, indent=2, ensure_ascii=False)
    print("\n >> Dados JSON atualizados com sucesso.")


def exibir_modulos() -> None:
    """Exibe todos os módulos cadastrados no JSON."""
    dados = carregar_dados_com_seguranca()
    modulos = dados.get("modulos", [])

    if not modulos:
        print("\n >> Nenhum módulo cadastrado.")
        return

    print(f"\n--- MÓDULOS DA COLÔNIA ({len(modulos)} cadastrados) ---")
    consumo_total = 0.0
    for i, m in enumerate(modulos, start=1):
        # Garante que o consumo é um número válido
        try:
            consumo = float(m.get("consumo_kw", 0))
            if consumo < 0:
                consumo = 0.0
        except (ValueError, TypeError):
            consumo = 0.0
        consumo_total += consumo
        print(
            f"  {i:>2}. {m.get('nome', 'Desconhecido'):<25} | "
            f"tipo: {m.get('tipo', 'N/A'):<15} | "
            f"status: {m.get('status', 'N/A'):<12} | "
            f"consumo: {consumo:>6.1f} kW"
        )
    print("-" * 70)
    print(f"  Consumo total estimado: {consumo_total:.1f} kW")
    print("-" * 70)


def exibir_alertas() -> None:
    """Exibe todos os alertas operacionais cadastrados no JSON."""
    dados = carregar_dados_com_seguranca()
    alertas = dados.get("alertas", [])

    if not alertas:
        print(">> Nenhum alerta registrado.")
        return

    print(f"\n--- ALERTAS OPERACIONAIS ({len(alertas)} registrados) ---")
    for i, a in enumerate(alertas, start=1):
        marcador = "🔴" if validar_alerta_critico(a) else "🟡"
        print(
            f"  {i:>2}. {marcador} [{a.get('prioridade', 'N/A').upper()}] {a.get('modulo', 'Desconhecido')} — "
            f"{a.get('tipo_ocorrencia', 'N/A')}: {a.get('mensagem', 'N/A')} ({a.get('data', 'N/A')})"
        )
    print("-" * 70)


def cadastrar_modulo() -> None:
    """Cadastra um novo módulo interativamente e persiste no JSON."""
    dados = carregar_dados_com_seguranca()

    print("\n--- CADASTRO DE NOVO MÓDULO ---")
    nome = input("Nome do módulo: ").strip()
    tipo = input("Tipo (ex: habitacao, energia, laboratorio): ").strip()
    status = input("Status (operacional/inativo/manutencao): ").strip()

    while True:
        try:
            consumo_input = input("Consumo em kW: ").strip()
            consumo = float(consumo_input) if consumo_input else 0.0
            break
        except ValueError:
            print(">> Por favor, digite um número válido para o consumo.")

    # Validação dos dados
    eh_valido, mensagem_erro = validar_dados_modulo(nome, tipo, status, consumo)
    if not eh_valido:
        print(f">> Erro no cadastro: {mensagem_erro}")
        gravar_registro(f"Tentativa falha de cadastro de módulo: {mensagem_erro}", tipo="ERRO")
        return

    novo_modulo = {
        "nome": nome,
        "tipo": tipo.lower(),  # Normaliza para lowercase
        "status": status.lower(),  # Normaliza para lowercase
        "consumo_kw": consumo,
        "ultima_manutencao": datetime.now().strftime("%Y-%m-%d"),
    }

    dados.setdefault("modulos", []).append(novo_modulo)
    if salvar_dados_com_seguranca(dados):
        gravar_registro(f"Novo módulo cadastrado: {nome} ({status})", tipo="CADASTRO")
        print("\n >> Módulo cadastrado com sucesso.")
    else:
        print("\n >> Erro ao salvar os dados do módulo.")


# ==============================================================================
# BLOCO 3 — REGRA LÓGICA E SIMULAÇÃO DE IA (Integrante 2)
# ==============================================================================


def validar_alerta_critico(alerta: dict) -> bool:
    """
    Regra de negócio original (item 1.4 do enunciado):
        ALERTA_CRITICO = (FALHA AND CRITICO) OR (FALHA AND NOT CRITICO)

    Aplicando o Teorema da Simplificação (X.Y + X.~Y = X), com X = FALHA
    e Y = CRITICO, a variável CRITICO se cancela e a regra se reduz a:
        ALERTA_CRITICO = FALHA

    Ou seja: para o disparo do alerta importa apenas se houve falha —
    a criticidade adicional não muda o resultado da expressão.
    """

    if not isinstance(alerta, dict):
        return False
    return alerta.get("tipo_ocorrencia") == "falha_critica"



def liberar_consulta(usuario_autorizado: bool, modulo_ativo: bool) -> bool:
    """
    Segunda regra lógica do sistema, usando os teoremas de De Morgan
    (item 5.4 do enunciado: "liberar consulta apenas se o usuário estiver
    autorizado e o módulo estiver ativo").
 
    Regra de liberação:
        LIBERAR = AUTORIZADO AND ATIVO
 
    Regra complementar de bloqueio (a negação da liberação), aplicando
    De Morgan:
        NAO LIBERAR = NOT (AUTORIZADO AND ATIVO)
                     = NOT AUTORIZADO OR NOT ATIVO
 
    Ou seja: basta o usuário NÃO estar autorizado OU o módulo estar
    INATIVO para que a consulta seja bloqueada — não é preciso avaliar
    as duas condições negadas separadamente antes de decidir, o que
    simplifica a checagem de bloqueio no restante do sistema.
    """
    return usuario_autorizado and modulo_ativo
 
 
def bloquear_consulta(usuario_autorizado: bool, modulo_ativo: bool) -> bool:
    """Forma equivalente (via De Morgan) da negação de liberar_consulta()."""
    return (not usuario_autorizado) or (not modulo_ativo)



def montar_prompt_zero_shot(alerta: dict) -> str:
    """Prompt zero-shot: pede um resumo do alerta sem exemplos prévios."""
    return (
        "Resuma em uma frase, em tom técnico e objetivo, o seguinte alerta "
        f"operacional da colônia: módulo '{alerta.get('modulo', 'desconhecido')}', "
        f"ocorrência '{alerta.get('tipo_ocorrencia', 'nao_informada')}', "
        f"prioridade '{alerta.get('prioridade', 'nao_informada')}', "
        f"descrição: '{alerta.get('mensagem', '')}'."
    )


def montar_prompt_few_shot(solicitacao: str) -> str:
    """Prompt few-shot: dá exemplos de classificação antes de pedir a nova."""
    return (
        "Classifique solicitações da tripulação em: URGENTE, ROTINA ou INFORMATIVA.\n\n"
        "Exemplo 1: 'Vazamento de ar na Habitação' -> URGENTE\n"
        "Exemplo 2: 'Solicito troca de filtro na próxima manutenção' -> ROTINA\n"
        "Exemplo 3: 'Qual o horário do próximo pouso de suprimentos?' -> INFORMATIVA\n\n"
        f"Solicitação: '{solicitacao}' -> "
    )


def montar_prompt_saida_estruturada(alerta: dict) -> str:
    """Prompt que exige explicitamente uma saída estruturada em JSON."""
    return (
        "Responda APENAS com um JSON válido, sem texto adicional, no formato "
        '{"modulo": str, "critico": bool, "acao_recomendada": str}, '
        f"considerando o alerta: {json.dumps(alerta, ensure_ascii=False)}"
    )


def _resposta_mock(contexto: str = "geral") -> str:
    """
    Centraliza o texto de resposta simulada, evitando duplicidade entre
    os diferentes pontos onde simular_resposta_assistente() pode cair
    no fallback local.
    """
    textos = {
        "geral": (
            "[Resposta simulada] Alerta reconhecido. Recomenda-se isolar o "
            "módulo afetado e acionar a equipe de manutenção com "
            "prioridade compatível ao nível informado."
        ),
    }
    return textos.get(contexto, textos["geral"])


def simular_resposta_assistente(prompt: str) -> str:
    """
    Retorna a resposta do assistente inteligente.

    Se houver uma GEMINI_API_KEY configurada e a biblioteca google-genai
    instalada, faz a chamada real (mesmo cliente usado em main.py).
    Caso contrário, devolve uma resposta simulada localmente — o item 2.3
    do enunciado permite explicitamente essa simulação.
    """
    if _client:
        try:
            resposta = _client.models.generate_content(
                model="gemini-2.5-flash", contents=prompt
            ) 
            return (resposta.text or "").strip()
        except Exception as erro:  # falha de rede/quota etc. -> cai para o mock
            return (
                f"[IA indisponível ({erro}); resposta simulada] Alerta reconhecido "
                "e registrado para acompanhamento do Centro de Controle."
            )

    return _resposta_mock()


def analisar_alerta_operacional() -> None:
    """Opção 6 do menu: aplica a regra lógica sobre os alertas e chama a IA para os alertas críticos."""
    dados = carregar_dados_json()
    alertas = dados.get("alertas", [])

    if not alertas:
        print(">> Nenhum alerta cadastrado para analisar.")
        return


    print("\n" + "=" * 70)
    print("--- ANÁLISE LÓGICA DE ALERTAS E RESPOSTAS DO ASSISTENTE ---".center(70))
    print("=" * 70)

    for i, a in enumerate(alertas, start=1):
        critico = validar_alerta_critico(a)
        status = "🔴 CRÍTICO" if critico else "🟢 NÃO CRÍTICO"
        modulo_nome = a.get('modulo', 'Desconhecido')
        
        print(f"\n[{i}] Módulo: {modulo_nome} ")
        print(f"    Status             : {status}")
        print(f"    Tipo de Ocorrência : {a.get('tipo_ocorrencia', 'N/A')}")
        print(f"    Prioridade         : {a.get('prioridade', 'N/A').upper()}")
        print(f"    Descrição          : {a.get('mensagem', 'N/A')}")

        if critico:
            prompt = montar_prompt_zero_shot(a)
            resposta = simular_resposta_assistente(prompt)
            
            print(f"\n    PROMPT ZERO-SHOT:")
            print(f"      \"{prompt}\"")
            print(f"\n     RESPOSTA DA IA:")
            print(f"       \"{resposta}\"")
            
            gravar_registro(
                f"Alerta crítico analisado ({modulo_nome}): {resposta}",
                tipo="RESPOSTA_IA",
            )
            print("-" * 70)



def simular_interacao_assistente() -> None:
    """Opção 7 do menu: demonstra os três tipos de prompt exigidos no item 1.5."""
    dados = carregar_dados_json()
    alertas = dados.get("alertas", [])
    alerta_exemplo = _escolher_alerta_exemplo(alertas)

    print("\n" + "=" * 70)
    print("SIMULAÇÃO DE INTERAÇÃO COM O ASSISTENTE INTELIGENTE".center(70))
    print("=" * 70)
 
    print("\n[1] PROMPT ZERO-SHOT (resumo de alerta):")
    prompt_zs = montar_prompt_zero_shot(alerta_exemplo)
    print(f"\n    Prompt: {prompt_zs}")
    print(f" \n   Resposta: {simular_resposta_assistente(prompt_zs)}")
    print("-" * 70)
 
    print("\n[2] PROMPT FEW-SHOT (classificação de solicitação):")
    print("    Dica: Digite uma demanda da colônia (ex: 'Falta oxigênio no setor B','Preciso de troca de filtro' ou 'Qual a previsão do tempo?')")
    solicitacao = (
        input("  Digite uma solicitação da tripulação para classificar: ").strip() or "Preciso de mais água na Habitação até amanhã"
    )
    prompt_fs = montar_prompt_few_shot(solicitacao)
    print(f" \n   Resposta: {simular_resposta_assistente(prompt_fs)}")
    print("-" * 70)
 
    print("\n[3] PROMPT DE SAÍDA ESTRUTURADA (JSON):")
    prompt_est = montar_prompt_saida_estruturada(alerta_exemplo)
    print(f" \n Resposta: {simular_resposta_assistente(prompt_est)}")
    print("-" * 70)
 
    gravar_registro(
        "Simulação de interação com o assistente executada.", tipo="RESPOSTA_IA"
    )


def _escolher_alerta_exemplo(alertas: list) -> dict:
    """
    Deixa o usuário escolher qual alerta salvo usar como exemplo nos
    prompts (opção 7), em vez de sempre pegar o primeiro da lista.
    Se não houver alertas ou a escolha for inválida, usa um exemplo padrão.
    """
    padrao = {
        "modulo": "MOD-OXY-01",
        "tipo_ocorrencia": "falha_critica",
        "prioridade": "alta",
        "mensagem": "Exemplo genérico de alerta para demonstração de prompts.",
        "data": datetime.now().strftime("%Y-%m-%d"),
    }
 
    if not alertas:
        print("\n>> Nenhum alerta cadastrado no sistema. Usando exemplo padrão.")
        return padrao
        
    print("\n" + "-" * 70)
    print("SELECIONE UM ALERTA PARA A SIMULAÇÃO DOS PROMPTS".center(70))
    print("=" * 70)

    print(f"\n  [0] - Módulo: {padrao['modulo']} - Exemplo padrão de alerta")
    for i, a in enumerate(alertas, start=1):
        print(f"  [{i}] - Módulo: {a.get('modulo', '???')} — {a.get('tipo_ocorrencia', '???')}")
    print("=" * 70)
 
    while True:
        escolha = input("Digite o número da opção desejada: ").strip()
        
        if escolha == "": # Se o usuário apertar Enter direto, assume 0
            print(f">> Usando o exemplo padrão: {padrao['modulo']}")
            return padrao

        if escolha.isdigit():
            indice = int(escolha)
            if indice == 0:
                print(f">> Usando o exemplo padrão: {padrao['modulo']}")
                return padrao
            elif 1 <= indice <= len(alertas):
                alerta_escolhido = alertas[indice - 1]
                print(f">> Alerta selecionado: {alerta_escolhido.get('modulo')}")
                return alerta_escolhido

        print(">> Opção inválida! Digite um número válido listado acima.")
 
 
def verificar_liberacao_consulta() -> None:
    """
    Demonstra a segunda regra lógica (De Morgan), aplicando liberar_consulta()/bloquear_consulta() de forma interativa.
    """

    print("\n" + "=" * 70)
    print("VALIDAÇÃO LÓGICA DE ACESSO".center(70))
    print("=" * 70)

    resposta_autorizado = input("Usuário está autorizado? (s/n): ").strip().lower()
    resposta_ativo = input("Módulo está ativo? (s/n): ").strip().lower()
 
    autorizado = resposta_autorizado == "s"
    ativo = resposta_ativo == "s"
 
    liberado = liberar_consulta(autorizado, ativo)
    bloqueado = bloquear_consulta(autorizado, ativo)
 
    print(f"\n>> LIBERAR = AUTORIZADO AND ATIVO -> {liberado}")
    print(f">> NAO LIBERAR (De Morgan) = NOT AUTORIZADO OR NOT ATIVO -> {bloqueado}")
    print(">> Consulta LIBERADA." if liberado else ">> Consulta BLOQUEADA.")
    print("=" * 70)
 
    gravar_registro(
        f"Verificação de liberação de consulta: autorizado={autorizado}, "
        f"ativo={ativo}, resultado={'liberado' if liberado else 'bloqueado'}",
        tipo="VALIDACAO_LOGICA",
    )


def adicionar_registro_manual() -> None:
    """Adiciona um registro manual ao arquivo de registros (TXT)."""
    mensagem = input("Digite o registro a ser salvo: ").strip()
    if mensagem:
        gravar_registro(mensagem, tipo="MANUAL")
        print("\n >> Registro manual salvo com sucesso.")
    else:
        print("\n >> Registro vazio não foi salvo.")


# ==============================================================================
# BLOCO 4 — MENU DE NAVEGAÇÃO (execução interativa/standalone)
# ==============================================================================


def exibir_menu() -> None:
    print("\n" + "=" * 70)
    print("NÚCLEO COGNITIVO DA AURORA SIGER (NCAS)".center(70))
    print("=" * 70)
    print("1 - Cadastrar novo módulo")
    print("2 - Consultar registros salvos (TXT)")
    print("3 - Adicionar registro manual (TXT)")
    print("4 - Exibir módulos cadastrados (JSON)")
    print("5 - Exibir alertas operacionais (JSON)")
    print("6 - Analisar alerta operacional (validação lógica + IA)")
    print("7 - Simular resposta do assistente inteligente")
    print("8 - Verificar liberação de consulta a módulo (regra De Morgan)")
    print("0 - Sair")
    print("=" * 70)


def main() -> None:
    """Loop interativo — usado quando o arquivo é executado diretamente."""
    gravar_registro("Sistema NCAS iniciado.", tipo="SISTEMA")

    acoes = {
        "1": cadastrar_modulo,
        "2": ler_registros,
        "3": adicionar_registro_manual,
        "4": exibir_modulos,
        "5": exibir_alertas,
        "6": analisar_alerta_operacional,
        "7": simular_interacao_assistente,
        "8": verificar_liberacao_consulta,
    }

    try:
        while True:
            exibir_menu()
            opcao = input("Escolha uma opção: ").strip()

            if opcao == "0":
                gravar_registro("Sistema NCAS encerrado.", tipo="SISTEMA")
                print(">> Encerrando o Núcleo Cognitivo. Até logo!")
                break
            elif opcao in acoes:
                acoes[opcao]()
            else:
                print(">> Opção inválida. Tente novamente.")
    except (KeyboardInterrupt, EOFError):
        # Garante que o encerramento seja registrado mesmo se o usuário
        # sair com Ctrl+C ou fechar a entrada abruptamente.
        gravar_registro("Sistema NCAS encerrado (interrupção do usuário).", tipo="SISTEMA")
        print("\n>> Encerrando o Núcleo Cognitivo. Até logo!")


# ==============================================================================
# BLOCO 5 — PONTO DE ENTRADA NÃO INTERATIVO PARA O main.py (PIPELINE INTEGRADO)
#
# Segue o mesmo padrão de executar_fase1()...executar_fase4(): sem input(),
# imprime um relatório e devolve um dicionário-resumo para o Data Lake
# consolidado em main.py.
# ==============================================================================

def executar_fase5(client=None, res_f2=None, res_f4=None) -> dict:
    """
    Executa a Fase 5 integrando as falhas de pouso (Fase 2) e a topologia (Fase 4)
    diretamente no arquivo JSON do NCAS para gerar análises da IA.
    """
    global _client
    if client is not None:
        _client = client

    print("\n" + "=" * 85)
    print("INICIANDO FASE 5: NÚCLEO COGNITIVO DA AURORA SIGER (NCAS)".center(85))
    print("=" * 85)

    # Limpa a base atual e reconstrói o JSON com o cenário real do pipeline
    dados = {"modulos": [], "alertas": []}

    # 1. Alimentando Módulos Operacionais a partir da Rede (Fase 4)
    if res_f4:
        for mod in res_f4.get("modulos_operacionais", []):
            dados["modulos"].append(
                {
                    "nome": mod,
                    "tipo": "infraestrutura",
                    "status": "operacional",
                    "consumo_kw": 0.0,
                    "ultima_manutencao": datetime.now().strftime("%Y-%m-%d"),
                }
            )

    # 2. Alimentando Alertas Críticos a partir das Falhas de Pouso (Fase 2)
    if res_f2:
        for mod_falho in res_f2.get("em_espera", []):
            dados["alertas"].append(
                {
                    "modulo": mod_falho,
                    "tipo_ocorrencia": "falha_critica",
                    "prioridade": "alta",
                    "mensagem": "Módulo retido em órbita ou destruído durante a descida (Fase 2).",
                    "data": datetime.now().strftime("%Y-%m-%d"),
                }
            )

    # Salva o arquivo JSON integrando o pipeline todo
    salvar_dados_json(dados)

    alertas_criticos = [a for a in dados["alertas"] if validar_alerta_critico(a)]
    respostas_ia = []

    for alerta in alertas_criticos:
        prompt = montar_prompt_zero_shot(alerta)
        resposta = simular_resposta_assistente(prompt)
        respostas_ia.append({"modulo": alerta["modulo"], "resposta": resposta})

    imprimir_quadro(
        "RESUMO NCAS",
        [
            f"Módulos em rede (Fase 4): {len(dados['modulos'])}",
            f"Alertas de Pouso (Fase 2): {len(dados['alertas'])}",
            f"Alertas críticos (Regra Lógica): {len(alertas_criticos)}",
            f"Análises de IA geradas: {len(respostas_ia)}",
        ],
    )

    gravar_registro(
        f"Fase 5 executada via pipeline integrado. {len(alertas_criticos)} alertas processados.",
        tipo="SISTEMA",
    )

    return {
        "modulos": dados["modulos"],
        "total_alertas": len(dados["alertas"]),
        "alertas_criticos": alertas_criticos,
        "respostas_ia": respostas_ia,
    }


if __name__ == "__main__":
    main()
